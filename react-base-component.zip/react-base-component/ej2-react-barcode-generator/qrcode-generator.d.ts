/**
 * qrcode-generator
 */
export * from './src/qrcode-generator/index';
