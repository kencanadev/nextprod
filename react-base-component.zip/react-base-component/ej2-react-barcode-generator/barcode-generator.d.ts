/**
 * barcode-generator
 */
export * from './src/barcode-generator/index';
