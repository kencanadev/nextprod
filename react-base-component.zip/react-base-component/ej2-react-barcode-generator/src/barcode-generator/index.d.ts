export * from './barcodegenerator.component';
