export * from './datamatrixgenerator.component';
