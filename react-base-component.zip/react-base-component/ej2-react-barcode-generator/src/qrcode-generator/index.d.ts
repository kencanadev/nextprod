export * from './qrcodegenerator.component';
