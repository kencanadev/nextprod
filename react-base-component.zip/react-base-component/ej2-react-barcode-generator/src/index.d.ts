export * from './barcode-generator';
export * from './qrcode-generator';
export * from './datamatrix-generator';
export { Inject } from '@syncfusion/ej2-react-base';
export * from '@syncfusion/ej2-barcode-generator';
