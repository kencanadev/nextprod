/**
 * datamatrix-generator
 */
export * from './src/datamatrix-generator/index';
