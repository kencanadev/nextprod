export declare function compile(templateElement: any, helper?: Object): (data: Object | JSON, component?: any, propName?: any, element?: any) => Object;
