/**
 * speed-dial
 */
export * from './src/speed-dial/index';
