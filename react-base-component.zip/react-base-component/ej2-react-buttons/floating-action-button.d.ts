/**
 * floating-action-button
 */
export * from './src/floating-action-button/index';
