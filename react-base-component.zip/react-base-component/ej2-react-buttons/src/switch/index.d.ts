export * from './switch.component';
